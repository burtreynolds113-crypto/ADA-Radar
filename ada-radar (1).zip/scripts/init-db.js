import { initSchema } from '../db.js';

// Initialize the database schema and log a message
initSchema();
console.log('Database initialized');