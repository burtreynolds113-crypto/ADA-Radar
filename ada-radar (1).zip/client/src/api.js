import axios from 'axios';

// Base URL for API calls. VITE_API_BASE_URL should be defined in your environment
// (e.g. .env file or Replit secrets) and point to your backend server (with /api).
const API_BASE = import.meta.env.VITE_API_BASE_URL;

export const api = axios.create({
  baseURL: API_BASE,
  withCredentials: true
});

export async function fetchSites() {
  const { data } = await api.get('/sites');
  return data;
}

export async function addSite(url) {
  const { data } = await api.post('/sites', { url });
  return data;
}

export async function scanSite(id) {
  const { data } = await api.post(`/sites/${id}/scan`);
  return data;
}

export async function createCheckoutSession(plan) {
  const { data } = await api.post('/billing/create-checkout-session', { plan });
  return data.url;
}