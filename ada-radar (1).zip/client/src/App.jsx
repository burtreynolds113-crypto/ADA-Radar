import React, { useEffect, useState } from 'react';
import {
  ClerkProvider,
  SignedIn,
  SignedOut,
  SignInButton,
  UserButton,
  useUser
} from '@clerk/clerk-react';
import { fetchSites, addSite, scanSite, createCheckoutSession } from './api.js';
import './styles.css';

function Dashboard() {
  const { user } = useUser();
  const [sites, setSites] = useState([]);
  const [newUrl, setNewUrl] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSites();
  }, []);

  async function loadSites() {
    const data = await fetchSites();
    setSites(data);
  }

  async function handleAddSite(e) {
    e.preventDefault();
    if (!newUrl) return;
    setLoading(true);
    await addSite(newUrl);
    setNewUrl('');
    await loadSites();
    setLoading(false);
  }

  async function handleScan(id) {
    setLoading(true);
    const result = await scanSite(id);
    await loadSites();
    alert(`Scan complete. Score: ${result.score}`);
    setLoading(false);
  }

  async function handleUpgrade(plan) {
    const url = await createCheckoutSession(plan);
    window.location.href = url;
  }

  return (
    <div className="app">
      <header className="header">
        <h1>ADA Radar</h1>
        <UserButton />
      </header>

      <section className="hero">
        <h2>Find ADA website risks in 60 seconds.</h2>
        <p>Paste a URL, hit scan, and see a clear score + fix list.</p>
      </section>

      <section className="pricing">
        <h3>Plans</h3>
        <div className="cards">
          <div className="card">
            <h4>Solo</h4>
            <p>$39 / month</p>
            <button onClick={() => handleUpgrade('solo')}>Start Solo</button>
          </div>
          <div className="card">
            <h4>Agency</h4>
            <p>$149 / month</p>
            <button onClick={() => handleUpgrade('agency')}>Start Agency</button>
          </div>
          <div className="card">
            <h4>Pro</h4>
            <p>$299 / month</p>
            <button onClick={() => handleUpgrade('pro')}>Start Pro</button>
          </div>
        </div>
      </section>

      <section className="sites">
        <h3>Your sites</h3>
        <form onSubmit={handleAddSite} className="add-site">
          <input
            type="url"
            placeholder="https://client-site.com"
            value={newUrl}
            onChange={e => setNewUrl(e.target.value)}
            required
          />
          <button type="submit" disabled={loading}>Add & scan</button>
        </form>

        <table className="sites-table">
          <thead>
            <tr>
              <th>URL</th>
              <th>Last score</th>
              <th>Last scan</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {sites.map(site => (
              <tr key={site.id}>
                <td>{site.url}</td>
                <td>{site.lastScan ? site.lastScan.score : '—'}</td>
                <td>{site.lastScan ? site.lastScan.created_at : 'Never'}</td>
                <td>
                  <button onClick={() => handleScan(site.id)} disabled={loading}>Scan now</button>
                </td>
              </tr>
            ))}
            {sites.length === 0 && (
              <tr>
                <td colSpan={4}>No sites yet. Add one above.</td>
              </tr>
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}

export default function App() {
  const clerkPubKey = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;
  return (
    <ClerkProvider publishableKey={clerkPubKey}>
      <SignedOut>
        <div className="app">
          <header className="header">
            <h1>ADA Radar</h1>
            <SignInButton>
              <button>Sign in</button>
            </SignInButton>
          </header>
          <main className="hero">
            <h2>Stop ADA demand letters before they hit your inbox.</h2>
            <p>Sign in, paste a URL, get a risk score in under a minute.</p>
            <SignInButton>
              <button>Get started</button>
            </SignInButton>
          </main>
        </div>
      </SignedOut>
      <SignedIn>
        <Dashboard />
      </SignedIn>
    </ClerkProvider>
  );
}