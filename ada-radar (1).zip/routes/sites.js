import express from 'express';
import db from '../db.js';
import { scanUrl } from '../scanService.js';

const router = express.Router();

/**
 * Get all sites for the authenticated user, along with the most recent scan for each site.
 */
router.get('/', (req, res) => {
  const userId = req.auth.userId;
  const sites = db.prepare('SELECT * FROM sites WHERE user_id = ? ORDER BY created_at DESC').all(userId);
  const lastScanStmt = db.prepare('SELECT * FROM scans WHERE site_id = ? ORDER BY created_at DESC LIMIT 1');
  const result = sites.map(site => {
    const lastScan = lastScanStmt.get(site.id);
    return { ...site, lastScan };
  });
  res.json(result);
});

/**
 * Add a new site for the authenticated user.
 */
router.post('/', (req, res) => {
  const userId = req.auth.userId;
  const { url } = req.body;
  const insert = db.prepare('INSERT INTO sites (user_id, url) VALUES (?, ?)');
  const info = insert.run(userId, url);
  res.json({ id: info.lastInsertRowid, url });
});

/**
 * Run a scan on a given site by ID.
 */
router.post('/:id/scan', async (req, res) => {
  const userId = req.auth.userId;
  const { id } = req.params;
  const site = db.prepare('SELECT * FROM sites WHERE id = ? AND user_id = ?').get(id, userId);
  if (!site) {
    return res.status(404).json({ error: 'Site not found' });
  }
  try {
    const { score, issues } = await scanUrl(site.url);
    const insertScan = db.prepare('INSERT INTO scans (site_id, score, issues_json) VALUES (?, ?, ?)');
    insertScan.run(site.id, score, JSON.stringify(issues));
    res.json({ score, issues });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Scan failed' });
  }
});

export default router;