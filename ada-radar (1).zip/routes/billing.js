import express from 'express';
import { stripe, PLAN_PRICE_IDS } from '../stripe.js';
import db from '../db.js';

const router = express.Router();

/**
 * Create a Stripe Checkout session for a given plan. The user must be authenticated.
 */
router.post('/create-checkout-session', async (req, res) => {
  const { plan } = req.body;
  const userId = req.auth.userId;

  if (!PLAN_PRICE_IDS[plan]) {
    return res.status(400).json({ error: 'Invalid plan' });
  }

  // Find or create the user in our database
  const getUser = db.prepare('SELECT * FROM users WHERE id = ?');
  let user = getUser.get(userId);
  if (!user) {
    const email = req.auth.sessionClaims?.email || req.auth.sessionClaims?.email_address;
    const insert = db.prepare('INSERT INTO users (id, email) VALUES (?, ?)');
    insert.run(userId, email || 'unknown@example.com');
    user = getUser.get(userId);
  }

  // Create a subscription checkout session
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{
        price: PLAN_PRICE_IDS[plan],
        quantity: 1
      }],
      success_url: `${process.env.FRONTEND_URL}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL}/billing/cancel`,
      client_reference_id: userId,
      customer_email: user.email
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

/**
 * Stripe webhook handler. This needs to use raw body parsing configured in index.js.
 * It will upsert subscription information when a checkout session completes.
 */
export function stripeWebhookHandler(req, res) {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error(err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const subscriptionId = session.subscription;
    const userId = session.client_reference_id;

    const upsert = db.prepare(`
      INSERT INTO subscriptions (user_id, stripe_customer_id, stripe_subscription_id, plan, status)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        stripe_customer_id = excluded.stripe_customer_id,
        stripe_subscription_id = excluded.stripe_subscription_id,
        plan = excluded.plan,
        status = excluded.status
    `);
    upsert.run(
      userId,
      session.customer,
      subscriptionId,
      'unknown',
      'active'
    );
  }

  res.json({ received: true });
}

export default router;